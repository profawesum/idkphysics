#include <iostream>
#include "Graphics.h"
#include "display.h"

Scene mScene;

IntVector2 ScreenSize = { 500,500 };
Vector2 MousePosition;
TriangleData Triangle;
LineData Line;
PointData point;
CircleData FirstCircle;
CircleData SecondCircle;
CircleData ThirdCircle;
CircleData FourthCircle;
FivePointShape fivePointShapeOne;
FivePointShape fivePointShapeTwo;

bool mouseDisable = false;


void ResetObjects() {
	FirstCircle.centerPoint.x = -9999;
	SecondCircle.centerPoint.x = -9999;
	ThirdCircle.centerPoint.x = -9999;
	FourthCircle.centerPoint.x = -9999;
	FirstCircle.radius = -9999;
	SecondCircle.radius = -9999;
	ThirdCircle.radius = -9999;
	FourthCircle.radius = -9999;
	Triangle.firstPoint.x = -9999;
	Triangle.thirdPoint.x = -9999;
	Triangle.secondPoint.x = -9999;
	point.data.x = -9999;
	fivePointShapeOne.firstPoint.x = -9999;
	fivePointShapeOne.secondPoint.x = -9999;
	fivePointShapeOne.thirdPoint.x = -9999;
	fivePointShapeOne.fourthPoint.x = -9999;
	fivePointShapeOne.fifthPoint.x = -9999;
	fivePointShapeTwo.firstPoint.x = -9999;
	fivePointShapeTwo.secondPoint.x = -9999;
	fivePointShapeTwo.thirdPoint.x = -9999;
	fivePointShapeTwo.fourthPoint.x = -9999;
	fivePointShapeTwo.fifthPoint.x = -9999;
}

float dotproduct(Vector3 VECA, Vector3 VECB)
{
	float product = 0;
	product += VECA.x * VECB.x;
	product += VECA.y * VECB.y;
	product += VECA.z * VECB.z;
	return (product);
}



float sign(glm::vec2 p1, glm::vec2 p2, glm::vec2 p3)
{
	return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y);
}

bool PointInTriangle(glm::vec2 pt, glm::vec2 v1, glm::vec2 v2, glm::vec2 v3)
{
	float d1, d2, d3;
	bool has_neg, has_pos;

	d1 = sign(pt, v1, v2);
	d2 = sign(pt, v2, v3);
	d3 = sign(pt, v3, v1);

	has_neg = (d1 < 0) || (d2 < 0) || (d3 < 0);
	has_pos = (d1 > 0) || (d2 > 0) || (d3 > 0);

	return !(has_neg && has_pos);
}


void mouse(int button, int state, int x, int y) { //Click

	if (button == 0) {
		mouseDisable = !mouseDisable; //toggle bool

		if (!mouseDisable) {
			if (Triangle.firstPoint.x == -9999) {
				Triangle.firstPoint.x = MousePosition.x;
				Triangle.firstPoint.y = MousePosition.y;
				wcout << L"Set first point for triangle at: " << Triangle.firstPoint.x << ":" << Triangle.firstPoint.y << endl;
			}
			else if (Triangle.secondPoint.x == -9999) {
				Triangle.secondPoint.x = MousePosition.x;
				Triangle.secondPoint.y = MousePosition.y;
				wcout << L"Set second point for triangle at: " << Triangle.secondPoint.x << ":" << Triangle.secondPoint.y << endl;
			}
			else if (Triangle.thirdPoint.x == -9999) {
				Triangle.thirdPoint.x = MousePosition.x;
				Triangle.thirdPoint.y = MousePosition.y;
				wcout << L"Set third point for triangle at: " << Triangle.thirdPoint.x << ":" << Triangle.thirdPoint.y << endl;

				mScene.GameObjects.push_back(new GameObject(Triangle));
				wcout << L"Triangle Made" << endl;
			}
			else if (point.data.x == -9999) {

				point.data.x = MousePosition.x;
				point.data.y = MousePosition.y;
				point.data.z = -0.5f;

				wcout << L"Set point at: " << point.data.x << ":" << point.data.y << endl;

				mScene.GameObjects.push_back(new GameObject(point));
				wcout << L"Point Made" << endl;
				cout << "Mouse at: " << MousePosition.x << "|" << MousePosition.y << endl;
			}
		}
	}
	}
void mouseMovement(int x, int y) {
	float aX = (float(x) - (ScreenSize.x / 2)) / (ScreenSize.x / 2);
	float aY = (float(y) - (ScreenSize.y / 2)) / (ScreenSize.y / 2);
	//wcout << L"Adjusted X:" << aX << L" Y:" << aY << endl;
	MousePosition = { aX, aY };
}


void keyboard(unsigned char key, int, int) {
		if (key == 114 || key == 82) { //r to reset
			for (size_t i = 0; i < mScene.GameObjects.size(); i++)
			{
				mScene.GameObjects.at(i)->~GameObject();
				mScene.GameObjects.erase(mScene.GameObjects.begin() + i);
				i--;
			}
			ResetObjects();
		}
	if (key == 27) { //esc
		//Console_OutputLog(L"Exitting OpenGL...", LOGINFO);
		glutLeaveMainLoop();
	}
}

void Render() {
	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

	for (size_t i = 0; i < mScene.GameObjects.size(); i++) //Render Objects
	{
		mScene.GameObjects.at(i)->Render();
	}

	glutSwapBuffers();
}


void Update() {
	Render();
}

int main(int argc, char** argv)
{

	for (size_t i = 0; i < mScene.GameObjects.size(); i++)
	{

		mScene.GameObjects.at(i)->~GameObject();
		mScene.GameObjects.erase(mScene.GameObjects.begin() + i);
		i--;
	}

	ResetObjects();

	//Start OpenGL

	//srand(static_cast <unsigned> (time(0)));
	//Console_OutputLog(L"OpenGL Service Setting Up...", LOGINFO);

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100, 50);
	glutInitWindowSize(ScreenSize.x, ScreenSize.y);

	glutCreateWindow("Viewport");

	if (glewInit() != GLEW_OK) {
		//Console_OutputLog(L"Glew INIT FAILED! The program cannot recover from this error", LOGFATAL);
		system("pause");
		return 0;
	}

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	glClearColor(0.0, 0.0, 0.0, 1.0);

	//Start

	//Console_OutputLog(L"OpenGL Service Starting...", LOGINFO);

	glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);

	glutDisplayFunc(Render);

	glutIdleFunc(Update);

	// handlers for keyboard input
	glutKeyboardFunc(keyboard);

	// mouse event handlers
	glutMouseFunc(mouse);
	glutPassiveMotionFunc(mouseMovement);

	glutMainLoop();

	return 0;

}

GameObject::GameObject(LineData positions, float lineWidth)
{
	type = GameObject::LINE;
	lineData = positions;
	lineWidth = lineWidth;

	color = Vector3{ (float)(rand() % 255) / 255  , (float)(rand() % 255) / 255, (float)(rand() % 255) / 255 };
}

GameObject::GameObject(TriangleData positions)
{
	type = GameObject::TRIANGLE;
	triangleData = positions;

	color = Vector3{ (float)(rand() % 255) / 255  , (float)(rand() % 255) / 255, (float)(rand() % 255) / 255 };

}

GameObject::GameObject(PointData _point)
{
	type = GameObject::POINT;

	pointData = _point;

	color = Vector3{ (float)(rand() % 255) / 255  , (float)(rand() % 255) / 255, (float)(rand() % 255) / 255 };
}

GameObject::GameObject(CircleData inCircle1, CircleData inCircle2)
{
	type = GameObject::CAPSULE;

	capsuleData.circle1 = inCircle1;
	capsuleData.circle2 = inCircle2;

	color = Vector3{ (float)(rand() % 255) / 255  , (float)(rand() % 255) / 255, (float)(rand() % 255) / 255 };
}

GameObject::GameObject(objectType letter, glm::vec3 pos)
{
	type = letter;
	pointData.data.x = pos.x;
	pointData.data.y = pos.y;
	pointData.data.z = pos.z;
}

GameObject::GameObject(FivePointShape _fiveshapeData)
{
	type = GameObject::FIVESHAPE;
	fiveshapeData = _fiveshapeData;

	color = Vector3{ (float)(rand() % 255) / 255  , (float)(rand() % 255) / 255, (float)(rand() % 255) / 255 };
}

GameObject::~GameObject()
{
}

void GameObject::Render()
{
	if (type == GameObject::TRIANGLE) {

		glBegin(GL_TRIANGLES);

		glColor3f(color.x, color.y, color.z);

		glVertex3f(triangleData.firstPoint.x, -triangleData.firstPoint.y, 0);
		glVertex3f(triangleData.secondPoint.x, -triangleData.secondPoint.y, 0);
		glVertex3f(triangleData.thirdPoint.x, -triangleData.thirdPoint.y, 0);

		glEnd();
	}
	else if (type == GameObject::LETTERO) {
		glm::vec3 orgin = glm::vec3(pointData.data.x, pointData.data.y, pointData.data.z);

		glLineWidth(10.0f);

		glColor3f(1.0f, 1.0f, 1.0f);

		//bottom
		glBegin(GL_LINES);
		glVertex3f(orgin.x, orgin.y, orgin.z);
		glVertex3f(orgin.x + 0.2f, orgin.y, orgin.z);
		glEnd();
		//right
		glBegin(GL_LINES);
		glVertex3f(orgin.x + 0.2f, orgin.y, orgin.z);
		glVertex3f(orgin.x + 0.2f, orgin.y + 0.2f, orgin.z);
		glEnd();
		//top
		glBegin(GL_LINES);
		glVertex3f(orgin.x, orgin.y + 0.2f, orgin.z);
		glVertex3f(orgin.x + 0.2f, orgin.y + 0.2f, orgin.z);
		glEnd();
		//left
		glBegin(GL_LINES);
		glVertex3f(orgin.x, orgin.y + 0.2f, orgin.z);
		glVertex3f(orgin.x, orgin.y, orgin.z);
		glEnd();
	}
	else if (type == GameObject::POINT) {
		glPointSize(5.0f);
		glBegin(GL_POINTS);

		glColor3f(color.x, color.y, color.z);

		glVertex3f(point.data.x, -point.data.y, point.data.z);

		glEnd();
	}
	else {
		cout << "NO RENDER TARGET" << endl;
	}
}


LineData GameObject::getLineData()
{
	return lineData;
}

TriangleData GameObject::getTriangleData()
{
	return triangleData;
}

