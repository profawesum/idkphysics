#include <iostream>
#include "Graphics.h"
#include "display.h"

Canvas canvas;

iVec2 ScreenSize = { 750,750 };
Vec2 mousePos;
TriangleData Triangle;
LineData Line;
PointData point;
FivePointShape multiPointShape;
FivePointShape multiPointShape2;

bool disableMouse = false;
bool changeColor = false;

void ResetShapes() {
	Triangle.point1.x = -9999;
	Triangle.point2.x = -9999;
	Triangle.point3.x = -9999;
	point.data.x = -9999;
	multiPointShape.point1.x = -9999;
	multiPointShape.point2.x = -9999;
	multiPointShape.point3.x = -9999;
	multiPointShape.point4.x = -9999;
	multiPointShape.point5.x = -9999;
	multiPointShape2.point1.x = -9999;
	multiPointShape2.point2.x = -9999;
	multiPointShape2.point3.x = -9999;
	multiPointShape2.point4.x = -9999;
	multiPointShape2.point5.x = -9999;
}


float dotproduct(Vector3 Vec1, Vector3 Vec2)
{
	float product = 0;
	product += Vec1.x * Vec2.x;
	product += Vec1.y * Vec2.y;
	product += Vec1.z * Vec2.z;
	return (product);
}

glm::vec2 getProj(vector<glm::vec3> shape, glm::vec3 axis) {

	Vector3 tmp = Vector3(shape.at(0).x, shape.at(0).y, shape.at(0).z);
	Vector3 axisTmp = Vector3(axis.x, axis.y, axis.z);

	double min = dotproduct(axisTmp, tmp);
	double max = min;

	for (int i = 1; i < shape.size(); i++) {
		// NOTE: the axis must be normalized to get accurate projections
		Vector3 tmp = Vector3(shape.at(i).x, shape.at(i).y, shape.at(i).z);
		Vector3 axisTmp = Vector3(axis.x, axis.y, axis.z);
		double p = dotproduct(axisTmp, tmp);
		if (p < min) {
			min = p;
		}
		else if (p > max) {
			max = p;
		}
	}


	glm::vec2 proj = glm::vec2(min, max);

	return proj;
}




bool SAT(FivePointShape shape1, FivePointShape shape2) {

	vector<glm::vec3> firstShape;
	vector<glm::vec3> secondShape;
	vector<glm::vec3> axi1;
	vector<glm::vec3> axi2;

	firstShape.push_back(shape1.point1);
	firstShape.push_back(shape1.point2);
	firstShape.push_back(shape1.point3);
	firstShape.push_back(shape1.point4);
	firstShape.push_back(shape1.point5);
	secondShape.push_back(shape2.point1);
	secondShape.push_back(shape2.point2);
	secondShape.push_back(shape2.point3);
	secondShape.push_back(shape2.point4);
	secondShape.push_back(shape2.point5);


	for (size_t i = 0; i < firstShape.size() - 1; i++)
	{
		glm::vec3 p1 = firstShape[i];
		glm::vec3 p2 = firstShape[i + 1];

		glm::vec3 edge = p1 - p2;

		glm::vec3 normal = glm::vec3(edge.y, -edge.x, edge.z);

		axi1.push_back(normal);
	}

	for (size_t i = 0; i < secondShape.size() - 1; i++)
	{
		glm::vec3 p1 = secondShape[i];
		glm::vec3 p2 = secondShape[i + 1];

		glm::vec3 edge = p1 - p2;

		glm::vec3 normal = glm::vec3(edge.y, -edge.x, edge.z);

		axi2.push_back(normal);
	}

	for (size_t i = 0; i < axi1.size(); i++)
	{
		glm::vec3 axis = axi1[i];

		//project both shapes
		glm::vec2 proj1 = getProj(firstShape, axis);
		glm::vec2 proj2 = getProj(secondShape, axis);

		//if we do not overlap return false
		if ((proj1.x > proj2.y) || (proj2.x > proj1.y)) {
			return false;
		}
	}

	for (size_t i = 0; i < axi2.size(); i++)
	{
		glm::vec3 axis = axi2[i];

		//project both shapes
		glm::vec2 proj1 = getProj(firstShape, axis);
		glm::vec2 proj2 = getProj(secondShape, axis);

		//if we do not overlap return false
		if ((proj1.x > proj2.y) || (proj2.x > proj1.y)) {
			return false;
		}
	}

	return true; //collision detected
}


void mouse(int button, int state, int x, int y) { //Click

	if (button == 0) {
		disableMouse = !disableMouse; //toggle bool

		if (!disableMouse) {
				mousePos.y = -mousePos.y;
				if (multiPointShape.point1.x == -9999) {
					multiPointShape.point1.x = mousePos.x;
					multiPointShape.point1.y = mousePos.y;
				}
				else if (multiPointShape.point2.x == -9999) {
					multiPointShape.point2.x = mousePos.x;
					multiPointShape.point2.y = mousePos.y;
				}
				else if (multiPointShape.point3.x == -9999) {
					multiPointShape.point3.x = mousePos.x;
					multiPointShape.point3.y = mousePos.y;
				}
				else if (multiPointShape.point4.x == -9999) {
					multiPointShape.point4.x = mousePos.x;
					multiPointShape.point4.y = mousePos.y;
				}
				else if (multiPointShape.point5.x == -9999) {
					multiPointShape.point5.x = mousePos.x;
					multiPointShape.point5.y = mousePos.y;
					canvas.shapes.push_back(new Object(multiPointShape));
				}
				else if (multiPointShape2.point1.x == -9999) {
					multiPointShape2.point1.x = mousePos.x;
					multiPointShape2.point1.y = mousePos.y;
				}
				else if (multiPointShape2.point2.x == -9999) {
					multiPointShape2.point2.x = mousePos.x;
					multiPointShape2.point2.y = mousePos.y;
				}
				else if (multiPointShape2.point3.x == -9999) {
					multiPointShape2.point3.x = mousePos.x;
					multiPointShape2.point3.y = mousePos.y;
				}
				else if (multiPointShape2.point4.x == -9999) {
					multiPointShape2.point4.x = mousePos.x;
					multiPointShape2.point4.y = mousePos.y;
				}
				else if (multiPointShape2.point5.x == -9999) {
					multiPointShape2.point5.x = mousePos.x;
					multiPointShape2.point5.y = mousePos.y;
					canvas.shapes.push_back(new Object(multiPointShape2));

					if (SAT(multiPointShape, multiPointShape2)) {
						cout << "Colliding Shapes" << endl;
					}
					else {
						cout << "Not colliding" << endl;
					}
				}
			}
		}
	}

void mouseMovement(int x, int y) {
	float X = (float(x) - (ScreenSize.x / 2)) / (ScreenSize.x / 2);
	float Y = (float(y) - (ScreenSize.y / 2)) / (ScreenSize.y / 2);
	mousePos = { X, Y };
}


void keyboard(unsigned char key, int, int) {
		if (key == 114 || key == 82) {
			for (size_t i = 0; i < canvas.shapes.size(); i++)
			{
				canvas.shapes.at(i)->~Object();
				canvas.shapes.erase(canvas.shapes.begin() + i);
				i--;
			}
			ResetShapes();
		}
	if (key == 27) { //esc
		glutLeaveMainLoop();
	}
}

void Render() {
	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

	for (size_t i = 0; i < canvas.shapes.size(); i++) //Render Objects
	{
		canvas.shapes.at(i)->Render();
	}

	glutSwapBuffers();
}


void Update() {
	Render();
}

int main(int argc, char** argv)
{

	for (size_t i = 0; i < canvas.shapes.size(); i++)
	{

		canvas.shapes.at(i)->~Object();
		canvas.shapes.erase(canvas.shapes.begin() + i);
		i--;
	}


	ResetShapes();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100, 50);
	glutInitWindowSize(ScreenSize.x, ScreenSize.y);

	glutCreateWindow("PHYSICS");

	if (glewInit() != GLEW_OK) {
		//Console_OutputLog(L"Glew INIT FAILED! The program cannot recover from this error", LOGFATAL);
		system("pause");
		return 0;
	}

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	glClearColor(0.0, 0.0, 0.0, 1.0);

	//Start

	//Console_OutputLog(L"OpenGL Service Starting...", LOGINFO);

	glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);

	glutDisplayFunc(Render);

	glutIdleFunc(Update);

	// handlers for keyboard input
	glutKeyboardFunc(keyboard);

	// mouse event handlers
	glutMouseFunc(mouse);
	glutPassiveMotionFunc(mouseMovement);

	glutMainLoop();

	return 0;

}

Object::Object(FivePointShape _fiveshapeData)
{
	this->type = Object::MULTISHAPE;
	this->multiShapeData = _fiveshapeData;

	color = Vector3{ 255,255,255 };
}


Object::~Object()
{
}

void Object::Render()
{
	 if (this->type == Object::MULTISHAPE) {
		glColor3f(this->color.x, this->color.y, this->color.z);
		glBegin(GL_TRIANGLE_FAN);

		glVertex3f(this->multiShapeData.point1.x, this->multiShapeData.point1.y, this->multiShapeData.point1.z);
		glVertex3f(this->multiShapeData.point2.x, this->multiShapeData.point2.y, this->multiShapeData.point2.z);
		glVertex3f(this->multiShapeData.point3.x, this->multiShapeData.point3.y, this->multiShapeData.point3.z);
		glVertex3f(this->multiShapeData.point4.x, this->multiShapeData.point4.y, this->multiShapeData.point4.z);
		glVertex3f(this->multiShapeData.point5.x, this->multiShapeData.point5.y, this->multiShapeData.point5.z);

		glEnd();
	}
}

LineData Object::getLineData()
{
	return lineData;
}

TriangleData Object::getTriangleData()
{
	return triangleData;
}

