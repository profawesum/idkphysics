#pragma once

class displayItems {

public:

	int initOpenGL(int argc, char **argv);


};