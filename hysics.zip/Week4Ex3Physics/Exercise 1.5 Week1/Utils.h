#pragma once
#include <glm.hpp>

struct Vector3 {
	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;

	inline Vector3(void) {

	}

	inline Vector3(const float X, const float Y, const float Z) {
		x = X;
		y = Y;
		z = Z;
	}

	inline Vector3 operator - (Vector3 B) {
		return Vector3{ x - B.x, y - B.y, z - B.z };
	};

	inline Vector3 operator + (Vector3 B) {
		return Vector3{ x + B.x, y + B.y, z + B.z };
	};

	inline Vector3 operator + (float B) {
		return Vector3{ x + B, y + B, z + B };
	};

	inline Vector3 operator / (Vector3 B) {
		return Vector3{ x / B.x, y / B.y, z / B.z };
	};

	inline Vector3 operator / (float B) {
		return Vector3{ x / B, y / B, z / B };
	};

	inline Vector3 operator * (Vector3 B) {
		return Vector3{ x * B.x, y * B.y, z * B.z };
	}

	inline Vector3 operator * (float B) {
		return Vector3{ x * B, y * B, z * B };
	}

	inline bool operator != (Vector3 B) {
		if (x != B.x || y != B.y || z != B.z) {
			return true;
		}
		return false;
	}

	inline bool operator == (Vector3 B) {
		if (x != B.x || y != B.y || z != B.z) {
			return false;
		}
		return true;
	}

};

struct Vec2 {
	float x = 0.0f;
	float y = 0.0f;
};

struct iVec2 {
	int x = 0;
	int y = 0;
};

struct TriangleData {
	Vector3 point1 = { -9999, -9999, 0 };
	Vector3 point2 = { -9999, -9999, 0 };
	Vector3 point3 = { -9999, -9999, 0 };
};

struct LineData {
	Vector3 point1 = { -9999, -9999, 0 };
	Vector3 point2 = { -9999, -9999, 0 };
};


struct PointData {
	Vector3 data = { -9999, -9999, 0 };
};

struct FivePointShape {
	glm::vec3 point1 = glm::vec3(-9999, -9999, 0);
	glm::vec3 point2 = glm::vec3(-9999, -9999, 0);
	glm::vec3 point3 = glm::vec3(-9999, -9999, 0);
	glm::vec3 point4 = glm::vec3(-9999, -9999, 0);
	glm::vec3 point5 = glm::vec3(-9999, -9999, 0);
};
