#pragma once
#include <glew.h>
#include <freeglut.h>
#include <vector>
#include <SOIL.h>
#include <glm.hpp>
#include <gtc/type_ptr.hpp>
#include <limits>

#include "Utils.h"

using namespace std;

class Object {
public:
	enum objectType {
		UNDEFINIED,
		TRIANGLE,
		LINE,
		POINT,
		MULTISHAPE
	};

	Object(LineData positions, float lineWidth); //line
	Object(TriangleData positions); //triangle
	Object(PointData _point); //triangle
	Object(FivePointShape _fiveshapeData); //shape
	~Object();
	objectType type;

	void Render();

	LineData getLineData();
	TriangleData getTriangleData();
	LineData lineData;
	TriangleData triangleData;
	PointData pointData;
	FivePointShape multiShapeData;

	bool killMe = false;
	float lineWidth = 1.0f;


	Vector3 color = { 0,0,0 };

};

class Canvas {
public:

	vector<Object*> shapes;
	bool drawingTriangle = true;

};


void mouse(int button, int state, int x, int y);
